#include <iostream>
#include <cmath>

using namespace std;
//double x;
int main()
{
    /*int grade;
    cin >> grade;
    bool isA = (90 <= grade && grade <= 100);
    cout << isA;*/
    //double x = (double) (3/5);
	//cout << (sqrt(2) * sqrt(2) == 2);
	//cout << x / 0;cout << x;
	/*int threeInt = 3;
	int fourInt  = 4;
	double threeDouble = 3.0;
	double fourDouble  = 4.0;
	cout << threeInt / fourInt << endl;
	cout << threeInt / fourDouble << endl;
	cout << threeDouble / fourInt << endl;
	cout << threeDouble / fourDouble << endl;*/
	/**int  arg1;
	arg1 = -1;
	int x, y, z;
	char myDouble = '5';
	char arg1 = 'A';
	cout << arg1 << "\n";
	int arg1;
	arg1 = -1;
	{
        char arg1 = 'A';
        cout << arg1 << "\n";
	}
	return 0;
	double F;
	cin >> F;
	double C = (F - 32) * (5 / 9);
    cout << C;
    if (10 > 5);
	 else; {
	    cout << "Here";
	 };**/

    return 0;
}
