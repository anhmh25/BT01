#include <iostream>
#include <cmath>

using namespace std;

int main()
{
    int x, y;
    cin >> x >> y;
    cout << sqrt(x * x + y * y);
    return 0;
}
